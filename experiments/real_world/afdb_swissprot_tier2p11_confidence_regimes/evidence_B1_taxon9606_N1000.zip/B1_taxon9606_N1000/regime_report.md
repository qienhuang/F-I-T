# Regime report - afdb_swissprot_tier2p11_confidence_regimes

- run_id: `B1_taxon9606_N1000`
- boundary_mode: `B1_COORD_PLUS_PAE`
- afdb_release_version: `v6`
- selected_n: `988` (target 1000; drawn 996; max_draw 5000)
- prereg_sha256: `7c38d25ee57a54418cd33e901f3eb769200211d0478d8bf738981fa1e5a3e747`

## Coherence gate

- status: **COHERENT**
- present: `[('C_primary', 2), ('C1_low_conf_frac', 2), ('C2_pae_offdiag', 2)]`
- range_bins: `2..2`

## Primary event detection (E_regime)

- event_found: **true**
- event_bin: `2`
- reason: `E_regime at bin_idx=2 hits=2`

## Event bins by estimator (audit)

- C_primary: `2`
- C1_low_conf_frac: `2`
- C2_pae_offdiag: `2`

## Interpretation rule

- If coherent: treat change points as signatures under the preregistered estimator tuple.

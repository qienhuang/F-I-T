# Regime report - afdb_swissprot_tier2p11_confidence_regimes

- run_id: `B1_taxon9606_N100`
- boundary_mode: `B1_COORD_PLUS_PAE`
- afdb_release_version: `v6`
- selected_n: `96` (target 100; drawn 100; max_draw 1000)
- prereg_sha256: `ede8f36b5eee2f7be9f234f83b7d2dce307fe5197c8dc94376e2a5f1518f6efd`

## Coherence gate

- status: **COHERENCE_NOT_TESTABLE**
- present: `[]`
- absent: `['C_primary', 'C1_low_conf_frac', 'C2_pae_offdiag']`
- note: `Only one (or zero) event-bearing estimator available; coherence not testable.`

## Primary event detection (E_regime)

- event_found: **false**
- event_bin: `None`
- reason: `too few bins`

## Event bins by estimator (audit)

- C_primary: `None`
- C1_low_conf_frac: `None`
- C2_pae_offdiag: `None`

## Interpretation rule

- If coherent: treat change points as signatures under the preregistered estimator tuple.

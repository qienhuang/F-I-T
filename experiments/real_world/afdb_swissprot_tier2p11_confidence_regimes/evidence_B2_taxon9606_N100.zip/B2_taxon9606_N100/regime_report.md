# Regime report - afdb_swissprot_tier2p11_confidence_regimes

- run_id: `B2_taxon9606_N100`
- boundary_mode: `B2_COORD_PLUS_PAE_PLUS_MSA`
- afdb_release_version: `v6`
- selected_n: `96` (target 100; drawn 100; max_draw 1000)
- prereg_sha256: `e592e25b4f844b11e408155e5b865f52afaacee45f8d7e761cb3fecabe1b07f8`

## Coherence gate

- status: **ESTIMATOR_UNSTABLE**
- present: `[('C_primary', 5), ('C1_low_conf_frac', 3), ('C2_pae_offdiag', 3), ('C3_msa_deficit', 8)]`
- absent: `[]`
- range_bins: `3..8`
- note: `Event disagreement or missing events across estimators.`

## Primary event detection (E_regime)

- event_found: **true**
- event_bin: `5`
- reason: `E_regime at bin_idx=5 hits=3`

## Event bins by estimator (audit)

- C_primary: `5`
- C1_low_conf_frac: `3`
- C2_pae_offdiag: `3`
- C3_msa_deficit: `8`

## Interpretation rule

- Label: **ESTIMATOR_UNSTABLE** -> do not interpret event location.

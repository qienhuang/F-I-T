# Regime report - afdb_swissprot_tier2p11_confidence_regimes

- run_id: `B2_taxon9606_N1000`
- boundary_mode: `B2_COORD_PLUS_PAE_PLUS_MSA`
- afdb_release_version: `v6`
- selected_n: `988` (target 1000; drawn 996; max_draw 5000)
- prereg_sha256: `d7bd30dee305a01b4501892ade53f710dd4997736db12b17a0a9d82bc7c1dcbd`

## Coherence gate

- status: **ESTIMATOR_UNSTABLE**
- present: `[('C_primary', 2), ('C1_low_conf_frac', 2), ('C2_pae_offdiag', 2), ('C3_msa_deficit', 8)]`
- absent: `[]`
- range_bins: `2..8`
- note: `Event disagreement or missing events across estimators.`

## Primary event detection (E_regime)

- event_found: **true**
- event_bin: `2`
- reason: `E_regime at bin_idx=2 hits=2`

## Event bins by estimator (audit)

- C_primary: `2`
- C1_low_conf_frac: `2`
- C2_pae_offdiag: `2`
- C3_msa_deficit: `8`

## Interpretation rule

- Label: **ESTIMATOR_UNSTABLE** -> do not interpret event location.

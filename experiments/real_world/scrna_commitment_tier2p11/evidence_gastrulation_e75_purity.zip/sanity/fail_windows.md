# Fail windows

The v0.1 run uses a single coherence gate across windows.

- Verdict: `ESTIMATOR_UNSTABLE`
- Observed rho: `0.04901960784313726`
- Threshold: `|rho| >= 0.2`

Interpretation is disallowed under EST discipline.

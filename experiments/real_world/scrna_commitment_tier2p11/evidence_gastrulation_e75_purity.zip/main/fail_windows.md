# Fail windows

None. Coherence gate passed for the preregistered estimator family.

# Fail windows

(Not generated yet; run `python -m src.regimes`.)

# scRNA commitment (EST-gated) — Regime report

**Verdict:** `OK_PER_WINDOW`

## Coherence gate (across windows)

- Estimators: `C_dim_collapse` vs `C_label_purity`
- Expected sign: `+1`
- Threshold: `|rho| >= 0.200`
- Observed rho: `0.581` (p=0.0145)
- Gate pass: `True`

## Notes

- This v0.1 run uses a single coherence test across windows (conservative).
- Window entries record per-window estimator values (not per-window rho/p-values).
- A future v0.2 can add per-window gates and a stability grid (window size sensitivity).
